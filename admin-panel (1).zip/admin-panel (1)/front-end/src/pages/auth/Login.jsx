import React from 'react'
import { Grid,Paper, Avatar, TextField, Button,} from '@material-ui/core'
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import './login.css';
import axios from "axios";

class Login extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            fields: {}
        }
    }

    login = (e) => {
        e.preventDefault();

        axios.post('https://react-admin-app-api-uki.herokuapp.com/user/login', this.state.fields)
            .then(response => {
                localStorage.setItem('accessToken', response.data.accesstoken);
                window.location.reload();
            })
            .catch(error => {
                alert("Invalid username / password")
            });

    }

    setFieldValues = (event) => {
        const fields = this.state.fields;
        const name = event.target.name;
        const value = event.target.value;

        fields[name] = value;

        this.setState({fields});
    }

    render = () => {
        const paperStyle={padding :20,height:'50vh',width:280, margin:"50px auto"}
        const avatarStyle={backgroundColor:'#F6821F'}
        const btnstyle={margin:'8px 0', backgroundColor:"#F6821F"}
        const textStyle={}
        return(
            <Grid>
                <Paper elevation={10} style={paperStyle}>
                    <Grid align='center'>
                         <Avatar style={avatarStyle}><LockOutlinedIcon/></Avatar>
                        <h2>Sign In</h2>
                    </Grid>
                    <form onSubmit={this.login}>
                        <TextField type="email" label='Email' placeholder='Enter email' name="email" style={textStyle} onChange={this.setFieldValues} fullWidth required/>
                        <TextField type='password' label='Password' placeholder='Enter password' name="password" style={textStyle} onChange={this.setFieldValues} fullWidth required/>
                        <FormControlLabel
                            control={
                            <Checkbox
                                name="checkedB"
                                color="primary"
                            />
                            }
                            label="Remember me"
                        />
                        <Button type='submit' variant="contained" style={btnstyle} fullWidth>Sign in</Button>
                    </form>
                </Paper>
            </Grid>
        )
    }
}

export default Login