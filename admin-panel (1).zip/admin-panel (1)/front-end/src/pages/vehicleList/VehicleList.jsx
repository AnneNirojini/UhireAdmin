import React from 'react';
import "./vehicleList.css";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";
import { vehicleRows } from "../../dummyData";
import { Link } from "react-router-dom";
import { useState } from "react";

export default function VehicleList({ vehicle }) {
  const [data, setData] = useState(vehicleRows);

  const handleDelete = (id) => {
    setData(data.filter((item) => item.id !== id));
  };

  const columns = [
    { field: {}, headerName: "ID", width: 90 },

    {
      field: "type",
      headerName: "VehicleType",
      width: 150,
    },
    {
      field: "model",
      headerName: "vehicleModel",
      width: 150,
    },
    // {
    //   field: "image",
    //   headerName: "image",
    //   width: 120,
    //   renderCell: (params) => {
    //     return (
    //       <div className="vehicleListVehicle">
    //         <img className="vehicleListImg" src={params.row.avatar} alt="" />
    //         {params.row.vehiclename}
    //       </div>
    //     );
    //   },
    // },
    {
      field: "name",
      headerName: "name",
      width: 150,
    },
    {
      field: "email",
      headerName: "Email",
      width: 150,
    },
    {
      field: "contact",
      headerName: "ContactNo",
      width: 150,
    },
    {
      field: "address",
      headerName: "Address",
      width: 160,
    },
    {
      field: "booked",
      headerName: "Booked",
      width: 120,
    },
    {
      field: "action",
      headerName: "Action",
      width: 150,
      renderCell: (params) => {
        return (
          <div>
            <Link to={"/vehicle/" + params.row.id}>
              <button className="vehicleListEdit">Edit</button>
            </Link>
            <DeleteOutline
              className="vehicleListDelete"
              onClick={() => handleDelete(params.row.id)}
            />
          </div>
        );
      },
    },
  ];

  return (
    <div className="vehicleList">
      <DataGrid
        rows={data}
        disableSelectionOnClick
        columns={columns}
        pageSize={8}
        checkboxSelection
      />
    </div>
  );
}




