import "./enquiryList.css";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";
import { enquiryRows } from "../../dummyData";
// import { enquiryRows } from "../../api/EnquiriesAPI";

// import { Link } from "react-router-dom";
import { useState } from "react";

export default function EnquiryList() {
  const [data, setData] = useState(enquiryRows);

  const handleDelete = (id) => {
    setData(data.filter((item) => item.id !== id));
  };

  const columns = [
    { field: "id", headerName: "ID", width: 90 },
    {
      field: "name",
      headerName: "Name",
      width: 150,
    },
    { field: "email", headerName: "E-mail", width: 150 },
    {
      field: "nic",
      headerName: "NIC/Passport",
      width: 160,
    },
    {
      field: "pLocation",
      headerName: "PickUpLocation",
      width: 160,
    },
    {
      field: "nop",
      headerName: "NOP",
      width: 110,
    },
    {
      field: "pDate",
      headerName: "pDate",
      width: 110,
    },
    {
      field: "rDate",
      headerName: "rDate",
      width: 110,
    },
    {
      field: "vType",
      headerName: "vType",
      width: 110,
    },



    {
      field: "status",
      headerName: "status",
      width: 120,
    },
    {
      field: "action",
      headerName: "Action",
      width: 120,
      renderCell: (params) => {
        return (
            <DeleteOutline
              className="enquiryListDelete"
              onClick={() => handleDelete(params.row.id)}
            />
        );
      },
    },
  ];

  return (
    <div className="enquiryList">
      <DataGrid
        rows={data}
        disableSelectionOnClick
        columns={columns}
        pageSize={8}
        checkboxSelection
      />
    </div>
  );
}
