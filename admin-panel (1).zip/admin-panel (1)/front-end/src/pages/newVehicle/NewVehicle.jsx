import React from 'react'
import "./newVehicle.css";
import {
  Publish,
} from "@material-ui/icons";
import axios from 'axios';


class AddVehicle extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      fields: {}
    }
  }

  submitForm = (event) => {
    event.preventDefault();
    const data = this.state.fields;
    console.log(data);
    // booked
    data.booked = "true";

    // const apiUrl = 'http://react-user-app-uki.herokuapp.com/api/enquiry';

    axios.post("/api/vehicles", data)
      .then(response => {
        //localStorage.setItem('accessToken', response.data.accesstoken);

        alert("Vehicle Added")
      })
      .catch(error => {
        alert("Something went wrong!")
      })
  }



  formInputHandler = (event) => {
    const e = event.target;
    const name = e.name;
    const value = e.value;
    const fields = this.state.fields;

    fields[name] = value;
    this.setState({ fields });
  }

  render() {
    return (
      <div className="newVehicle">
        <h1 className="newVehicleTitle">Add Vehicle</h1>
        <form onSubmit={this.submitForm} className="newVehicleForm">
          <div className="newVehicleItem">
            <label>Vehicle ID</label>
            <input onChange={this.formInputHandler} type="text" placeholder="Car001" name="vehicle_id" />
          </div>
          <div className="newVehicleItem">
            <label>Vehicle Owner Name</label>
            <input onChange={this.formInputHandler} type="text" placeholder="Raj Jeya" name="name" />
          </div>
          <div className="newVehicleItem">
            <label>Vehicle Type</label>
            <select onChange={this.formInputHandler} className="newVehicleSelect" name="vehicleType" id="vehicleType">
              <option value="car">Car</option>
              <option value="van">Van</option>
              <option value="bus">Bus</option>
            </select>
          </div>
          <div className="newVehicleItem">
            <label>Email</label>
            <input onChange={this.formInputHandler} type="email" placeholder="jeya@gmail.com" name="eMail" />
          </div>
          <div className="newVehicleItem">
            <label>Vehicle Model</label>
            <input onChange={this.formInputHandler} type="text" placeholder="BCU3" name="model" />
          </div>
          <div className="newVehicleItem">
            <label>Contact Number</label>
            <input onChange={this.formInputHandler} type="text" placeholder="+94 77 525 7454" name="contactNumber" />
          </div>
          <div className="newVehicleItem">
            <label>Service Type</label>
            <select onChange={this.formInputHandler} className="newVehicleSelect" name="ServiceType" id="vehicleType">
              <option value="wedding">Wedding Service</option>
              <option value="airport">Airport Service</option>
              <option value="optional">Optional Service</option>
            </select>
          </div>
          <div className="newVehicleItem">
            <label>Address</label>
            <input onChange={this.formInputHandler} type="text" placeholder="Kilinochchi | Srilanka" name="address" />
          </div>

          {/*<div className="newVehicleUpload">
            <img name="images"
              className="newVehicleImg"
              src="https://res.cloudinary.com/drmy319ph/image/upload/v1634029303/UHire-vehicles/hs07bpie7ombmgiunnak.jpg"
              alt=""
            />
            <label htmlFor="file">
              <Publish className="newVehicleIcon" />
            </label>
            <input type="file" id="file" style={{ display: "none" }} onChange={this.formInputHandler} />
    </div>*/}
          <br />
          <button type="submit" className="newVehicleButton" name="submit" >Create</button>

        </form>
      </div>
    );
  }
}

export default AddVehicle;
